//
//  YearAndMonthNow.h
//  Cal
//
//  Created by xujiadai on 18/10/24.
//  Copyright © 2018年 xujiadai. All rights reserved.
//
#import <Foundation/Foundation.h>

@interface YearAndMonthNow : NSObject

@property(nonatomic) int yearNow;
@property(nonatomic) int monthNow;

- (void) yearAndMonth;

@end
