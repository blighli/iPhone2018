//
//  AppDelegate.h
//  iostest02
//
//  Created by 贺晨韬 on 2018/9/26.
//  Copyright © 2018年 贺晨韬. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "RootViewController.h"

@interface AppDelegate : UIResponder <UIApplicationDelegate>
//@interface MyAppDelegate : UIResponder <UIApplicationDelegate>{
//    NSString *docs;
//}

@property (strong, nonatomic) UIWindow *window;
@property (strong, nonatomic) RootViewController *rtviewcontroller;


@end

