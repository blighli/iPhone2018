/****************************************************************************
 Copyright (c) 2017-2018 Xiamen Yaji Software Co., Ltd.
 
 http://www.cocos2d-x.org
 
 Permission is hereby granted, free of charge, to any person obtaining a copy
 of this software and associated documentation files (the "Software"), to deal
 in the Software without restriction, including without limitation the rights
 to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:
 
 The above copyright notice and this permission notice shall be included in
 all copies or substantial portions of the Software.
 
 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 THE SOFTWARE.
 ****************************************************************************/


#ifndef __PLAYER_TASK_SERVICE_PROTOCOL_H
#define __PLAYER_TASK_SERVICE_PROTOCOL_H

#include <string>

#include "cocos2d.h"
#include "PlayerMacros.h"
#include "PlayerServiceProtocol.h"

PLAYER_NS_BEGIN

class PlayerTask : public cocos2d::Ref
{
public:
    static const int STATE_IDLE = 0;
    static const int STATE_RUNNING = 1;
    static const int STATE_COMPLETED = 2;

    virtual ~PlayerTask() {};

    std::string getName() const;
    std::string getExecutePath() const;
    std::string getCommandLineArguments() const;
    std::string getOutput() const;
    int getState() const;
    bool isIdle() const;
    bool isRunning() const;
    bool isCompleted() const;
    float getLifetime() const;
    int getResultCode() const;

    virtual bool run() = 0;
    virtual void stop() = 0;
    virtual void runInTerminal() = 0;

protected:
    PlayerTask(const std::string &name,
               const std::string &executePath,
               const std::string &commandLineArguments);

    std::string _name;
    std::string _executePath;
    std::string _commandLineArguments;
    std::string _output;
    float _lifetime;
    int _state;
    int _resultCode;
};

class PlayerTaskServiceProtocol : public PlayerServiceProtocol
{
public:
    virtual PlayerTask *createTask(const std::string &name,
                                   const std::string &executePath,
                                   const std::string &commandLineArguments) = 0;
    virtual PlayerTask *getTask(const std::string &name) = 0;
    virtual void removeTask(const std::string &name) = 0;
};

PLAYER_NS_END

#endif // __PLAYER_TASK_SERVICE_PROTOCOL_H
